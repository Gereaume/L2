#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <liste_objet.h>


/*
 * A FAIRE
 */
