  void (*afficher) (objet_t *);
  err_t (*detruire) (objet_t **);